#include "myhwk09to11.h"
#include "data_proc.c"
#include "data_gen.c"
#include "output.c"


// 全局變數的定義 (Global Variable Definitions)
int numStu = NUM_STU;
int nSubj = N_SUBJ;
// 實際學分數和期望的平均/標準差只用到前 3 個元素
int credit[MAX_SUBJ] = { 3, 4, 2, 3, 3, 3, 3, 3, 3 };  // 各科幾學分 (第一科3, 第二科4, 第三科2)
float expMean[MAX_SUBJ] = { 75.0, 70.5, 82.0, 74.25, 75.5 };  // 期望的各科平均
float expStd[MAX_SUBJ] = { 7.5, 9.75, 8.5, 6.0, 5.0 };  // 期望的各科標準差

int main(void) {
    // 初始化亂數產生器
    srand((unsigned int)time(NULL));

    // 動態分配學生資料陣列
    Student *allStudents = (Student *)malloc(numStu * sizeof(Student));
    if (allStudents == NULL) {
        fprintf(stderr, "記憶體分配失敗。\n");
        return 1;
    }

    printf("--- 開始產生 %d 位學生的資料 (學號: 114開頭, 成績: 常態分佈) ---\n", numStu);

    // (a), (b) 產生學號、姓名和成績
    generate_data(allStudents, numStu);
    printf("--- 資料產生完成 ---\n");

    // (c) 計算加權平均分數
    calc_weighted_avg(allStudents, numStu);

    // (d) 依平均做排名 (排名在原始資料上進行，後續排序使用複製的陣列)
    rank_students(allStudents, numStu);
    printf("--- 平均分數計算與排名完成 ---\n");


    // (e) 依據平均分數做排名並印出資料 (Selection Sort)
    // 複製一份資料來進行排序，以保留原始資料的狀態，方便後續學號排序
    Student *rankedStudents = (Student *)malloc(numStu * sizeof(Student));
    if (rankedStudents == NULL) {
        fprintf(stderr, "記憶體分配失敗。\n");
        free(allStudents);
        return 1;
    }
    // 複製原始資料 (已包含排名資訊)
    memcpy(rankedStudents, allStudents, numStu * sizeof(Student));

    printf("\n==================================================================\n");
    printf(" (e) 依總成績 (加權平均) 由高到低排序 (Selection Sort) 並印出\n");
    printf("==================================================================\n");

    // (g) 測量排序時間
    double sortTime_rank = sort_by_rank_selection(rankedStudents, numStu);
    printf("\n*** 排序 (Selection Sort) 耗時: %.3f 秒 ***\n", sortTime_rank);

    // (e) 輸出排名後的資料
    print_data(rankedStudents, numStu, "依排名 (平均分數) 排序");

    // (e) 輸出統計數據
    calc_and_print_stats(rankedStudents, numStu);
    free(rankedStudents);


    // (f) 依據學號由小到大排序並印出資料 (Insertion Sort)
    printf("\n\n==================================================================\n");
    printf(" (f) 依學號由小到大排序 (Insertion Sort) 並印出\n");
    printf("==================================================================\n");

    // 複製一份資料來進行排序
    Student *idSortedStudents = (Student *)malloc(numStu * sizeof(Student));
    if (idSortedStudents == NULL) {
        fprintf(stderr, "記憶體分配失敗。\n");
        free(allStudents);
        return 1;
    }
    // 複製原始資料 (已包含排名資訊)
    memcpy(idSortedStudents, allStudents, numStu * sizeof(Student));

    // 進行學號排序並計時
    clock_t start_time_id = clock();
    sort_by_id_insertion(idSortedStudents, numStu);
    clock_t end_time_id = clock();
    double sortTime_id = (double)(end_time_id - start_time_id) / CLOCKS_PER_SEC;
    printf("\n*** 排序 (Insertion Sort) 耗時: %.3f 秒 ***\n", sortTime_id);


    // (f) 輸出學號排序後的資料
    print_data(idSortedStudents, numStu, "依學號排序");

    // (f) 輸出統計數據
    calc_and_print_stats(idSortedStudents, numStu);
    free(idSortedStudents);


    // 釋放原始資料記憶體
    free(allStudents);

    return 0;
}