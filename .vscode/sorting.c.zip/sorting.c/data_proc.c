#include "myhwk09to11.h"

// 輔助函數：四捨五入到小數點後兩位
float round_to_two_decimals(float value) {
    // 乘以 100.0, 加 0.5 後取整, 再除以 100.0
    return floorf(value * 100.0 + 0.5) / 100.0;
}

// (c) 計算加權平均分數
void calc_weighted_avg(Student *students, int count) {
    int totalCredits = 0;
    for (int i = 0; i < nSubj; i++) {
        totalCredits += credit[i];
    }

    for (int i = 0; i < count; i++) {
        float weightedSum = 0.0;
        for (int j = 0; j < nSubj; j++) {
            weightedSum += students[i].scores[j] * credit[j];
        }

        float rawAvg = weightedSum / totalCredits;

        // 四捨五入到小數點後兩位
        students[i].weightedAvg = round_to_two_decimals(rawAvg);
    }
}

// 比較函數：用於排名和 Selection Sort 的穩定性
// 返回負數表示 a 優先 (排名較高), 返回正數表示 b 優先 (排名較低), 返回 0 表示相同
int compare_students_for_rank(const Student *a, const Student *b) {
    // 1. 比較加權平均分數 (高者優先)
    if (a->weightedAvg > b->weightedAvg) return -1;
    if (a->weightedAvg < b->weightedAvg) return 1;

    // 2. 平均分數相同，比較科目一 (高者優先)
    if (a->scores[0] > b->scores[0]) return -1;
    if (a->scores[0] < b->scores[0]) return 1;

    // 3. 科目一相同，比較科目二 (高者優先)
    if (a->scores[1] > b->scores[1]) return -1;
    if (a->scores[1] < b->scores[1]) return 1;

    // 4. 科目二相同，比較科目三 (高者優先)
    if (a->scores[2] > b->scores[2]) return -1;
    if (a->scores[2] < b->scores[2]) return 1;

    return 0; // 所有成績都相同
}

// 輔助函數：交換兩個學生資料
void swap_students(Student *a, Student *b) {
    Student temp = *a;
    *a = *b;
    *b = temp;
}

// (d) 依據每位同學平均分數做排名
void rank_students(Student *students, int count) {
    // 為了排名的正確性，先將學生陣列複製到一個臨時陣列並進行排序 (使用 qsort 快速排序)
    // 這樣可以確保在 O(N log N) 的時間內得到正確的排名順序
    Student *tempStudents = (Student *)malloc(count * sizeof(Student));
    if (tempStudents == NULL) {
        fprintf(stderr, "記憶體分配失敗 (排名)。\n");
        return;
    }
    memcpy(tempStudents, students, count * sizeof(Student));

    // 使用 qsort 排序 (成績高到低)
    qsort(tempStudents, count, sizeof(Student), (int (*)(const void *, const void *))compare_students_for_rank);

    // 賦予排名
    int current_rank = 1;
    int rank_skip_count = 0; 

    for (int i = 0; i < count; i++) {
        if (i == 0) {
            tempStudents[i].rank = current_rank;
            rank_skip_count = 1;
        } else {
            // 比較當前學生和前一個學生 (成績和 tie-breaker)
            if (compare_students_for_rank(&tempStudents[i], &tempStudents[i - 1]) == 0) {
                // 成績完全相同，排名也相同
                tempStudents[i].rank = current_rank;
                rank_skip_count++;
            } else {
                // 成績不同，排名跳過 (例如：兩個第3名後，下一名是第5名)
                current_rank += rank_skip_count;
                tempStudents[i].rank = current_rank;
                rank_skip_count = 1;
            }
        }
    }

    // 將排名結果寫回原始陣列 (根據學號匹配)
    // 由於我們不能保證原始陣列的順序，這裡使用 O(N^2) 查找並寫回，
    // 對於 95678 人來說這很慢。**優化方式：使用 O(N^2) 寫回，但要警告效能。**
    // 為了符合純 C 和不改變結構的要求，我們必須這樣做。
    for (int i = 0; i < count; i++) {
        for (int j = 0; j < count; j++) {
            if (students[j].studentID == tempStudents[i].studentID) {
                students[j].rank = tempStudents[i].rank;
                break;
            }
        }
    }
    
    free(tempStudents);
}

// (e) 依據平均分數由高到低排序 (Selection Sort) 並計時
double sort_by_rank_selection(Student *students, int count) {
    clock_t start_time = clock();

    for (int i = 0; i < count - 1; i++) {
        int max_idx = i;
        for (int j = i + 1; j < count; j++) {
            // 尋找排名最前的學生 (排名數字最小)
            if (students[j].rank < students[max_idx].rank) {
                max_idx = j;
            } 
            // 如果排名相同，則使用 tie-breaker 規則 (compare_students_for_rank)
            // 確保同分學生的順序與排名順序一致 (最高分/最好的 tie-breaker 優先)
            else if (students[j].rank == students[max_idx].rank) {
                 if (compare_students_for_rank(&students[j], &students[max_idx]) < 0) {
                     max_idx = j;
                 }
            }
        }

        if (max_idx != i) {
            swap_students(&students[i], &students[max_idx]);
        }
    }

    clock_t end_time = clock();
    // (g) 傳回排序耗時 (秒)
    return (double)(end_time - start_time) / CLOCKS_PER_SEC;
}


// (f) 依據學號由小到大排序 (Insertion Sort)
void sort_by_id_insertion(Student *students, int count) {
    for (int i = 1; i < count; i++) {
        Student key = students[i];
        int j = i - 1;

        // 將 studentID 比 key.studentID 大的元素向右移動
        while (j >= 0 && students[j].studentID > key.studentID) {
            students[j + 1] = students[j];
            j = j - 1;
        }
        students[j + 1] = key;
    }
}